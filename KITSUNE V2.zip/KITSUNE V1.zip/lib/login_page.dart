import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'api_config.dart';
import 'splash.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage>
    with SingleTickerProviderStateMixin {
  final userController = TextEditingController();
  final passController = TextEditingController();
  final _formKey = GlobalKey<FormState>();

  bool isLoading = false;
  bool _obscurePassword = true;
  String? androidId;

  late AnimationController _controller;
  late Animation<double> _fadeAnim;
  late AnimationController _neonPulseController;
  late Animation<double> _neonPulse;

  final Color neonCyan = const Color(0xFF00D4FF);
  final Color neonPink = const Color(0xFFFF2E63);
  final Color neonPurple = const Color(0xFFBD00FF);
  final Color neonGreen = const Color(0xFF00E5A0);
  final Color neonYellow = const Color(0xFFFFB800);
  final Color bgDark = const Color(0xFF05050A);
  final Color bgCard = const Color(0xFF0A0A14);
  final Color bgSurface = const Color(0xFF11111F);

  @override
  void initState() {
    super.initState();
    _initAnim();
    initLogin();
  }

  void _initAnim() {
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    )..forward();
    _fadeAnim = CurvedAnimation(parent: _controller, curve: Curves.easeOut);

    _neonPulseController = AnimationController(
      duration: const Duration(milliseconds: 1500),
      vsync: this,
    )..repeat(reverse: true);
    _neonPulse = Tween<double>(begin: 0.4, end: 0.9).animate(_neonPulseController);
  }

  Future<void> initLogin() async {
    androidId = await getAndroidId();
    final prefs = await SharedPreferences.getInstance();
    final savedUser = prefs.getString("username");
    final savedPass = prefs.getString("password");
    final savedKey = prefs.getString("key");

    if (savedUser != null && savedPass != null && savedKey != null) {
      final uri = Uri.parse(
        "$apiBaseUrl/myInfo?username=$savedUser&password=$savedPass&androidId=$androidId&key=$savedKey",
      );
      try {
        final res = await http.get(uri);
        final data = jsonDecode(res.body);
        if (data['valid'] == true && mounted) {
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(
              builder: (_) => SplashScreen(
                username: savedUser,
                password: savedPass,
                role: data['role'],
                sessionKey: data['key'],
                expiredDate: data['expiredDate'],
                telegramId: (data['telegramId'] ?? '').toString(),
                listBug: (data['listBug'] as List? ?? []).map((e) => Map<String, dynamic>.from(e as Map)).toList(),
                listDoos: (data['listDDoS'] as List? ?? []).map((e) => Map<String, dynamic>.from(e as Map)).toList(),
                news: (data['news'] as List? ?? []).map((e) => Map<String, dynamic>.from(e as Map)).toList(),
              ),
            ),
          );
        }
      } catch (_) {}
    }
  }

  Future<String> getAndroidId() async {
    final deviceInfo = DeviceInfoPlugin();
    final android = await deviceInfo.androidInfo;
    return android.id;
  }

  Future<void> login() async {
    if (!_formKey.currentState!.validate()) return;
    final username = userController.text.trim();
    final password = passController.text.trim();
    setState(() => isLoading = true);

    try {
      final validate = await http.post(
        Uri.parse("$apiBaseUrl/validate"),
        body: {"username": username, "password": password, "androidId": androidId ?? "unknown_device"},
      );
      final validData = jsonDecode(validate.body);

      if (validData['expired'] == true) {
        _showPopup(title: "ACCESS EXPIRED", message: "Your access period has ended. Please renew.", color: neonYellow);
      } else if (validData['valid'] != true) {
        final String errorMsg = (validData['message'] ?? "").toLowerCase();
        if (errorMsg.contains("perangkat") || errorMsg.contains("device") || errorMsg.contains("another")) {
          _showPopup(title: "ACTIVE SESSION", message: "Account is logged in on another device.", color: neonPink);
        } else {
          _showPopup(title: "LOGIN FAILED", message: "Invalid username or password.", color: neonPink);
        }
      } else {
        final prefs = await SharedPreferences.getInstance();
        prefs.setString("username", username);
        prefs.setString("password", password);
        prefs.setString("key", validData['key']);
        prefs.setString("android_id", androidId ?? "unknown_device");
        if (mounted) {
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(
              builder: (_) => SplashScreen(
                username: username,
                password: password,
                role: validData['role'],
                sessionKey: validData['key'],
                expiredDate: validData['expiredDate'],
                telegramId: (validData['telegramId'] ?? '').toString(),
                listBug: (validData['listBug'] as List? ?? []).map((e) => Map<String, dynamic>.from(e as Map)).toList(),
                listDoos: (validData['listDDoS'] as List? ?? []).map((e) => Map<String, dynamic>.from(e as Map)).toList(),
                news: (validData['news'] as List? ?? []).map((e) => Map<String, dynamic>.from(e as Map)).toList(),
              ),
            ),
          );
        }
      }
    } catch (e) {
      _showPopup(title: "CONNECTION ERROR", message: "Failed to connect to server.", color: neonPink);
    }
    setState(() => isLoading = false);
  }

  void _showPopup({required String title, required String message, required Color color}) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: bgCard,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24), side: BorderSide(color: color.withOpacity(0.5), width: 1.5)),
        title: Row(
          children: [
            Icon(Icons.error_outline_rounded, color: color, size: 28),
            const SizedBox(width: 12),
            Text(title, style: TextStyle(color: color, fontWeight: FontWeight.bold, fontSize: 18, fontFamily: 'Orbitron')),
          ],
        ),
        content: Text(message, style: const TextStyle(color: Colors.white70, fontSize: 14)),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text("CLOSE", style: TextStyle(color: color, fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    _neonPulseController.dispose();
    userController.dispose();
    passController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        width: double.infinity,
        height: double.infinity,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [bgDark, bgSurface, const Color(0xFF000000)],
          ),
        ),
        child: SafeArea(
          child: FadeTransition(
            opacity: _fadeAnim,
            child: Center(
              child: SingleChildScrollView(
                padding: const EdgeInsets.symmetric(horizontal: 24),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    _buildLogo(),
                    const SizedBox(height: 24),
                    _buildTitle(),
                    const SizedBox(height: 32),
                    Form(
                      key: _formKey,
                      child: Column(
                        children: [
                          _buildInput(userController, "USERNAME", Icons.person_outline_rounded),
                          const SizedBox(height: 20),
                          _buildInput(passController, "PASSWORD", Icons.lock_outline_rounded, true),
                          const SizedBox(height: 28),
                          _buildButton(),
                        ],
                      ),
                    ),
                    const SizedBox(height: 32),
                    _buildPriceList(),
                    const SizedBox(height: 24),
                    _buildNeonFooter(),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildLogo() {
    return AnimatedBuilder(
      animation: _neonPulse,
      builder: (context, child) {
        return Container(
          width: 100,
          height: 100,
          decoration: BoxDecoration(
            gradient: LinearGradient(colors: [neonPurple, neonPink]),
            borderRadius: BorderRadius.circular(28),
            boxShadow: [
              BoxShadow(color: neonPink.withOpacity(_neonPulse.value), blurRadius: 30, spreadRadius: 5),
              BoxShadow(color: neonPurple.withOpacity(_neonPulse.value), blurRadius: 20, spreadRadius: 2),
            ],
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(26),
            child: Image.asset('assets/images/logo.png', fit: BoxFit.cover),
          ),
        );
      },
    );
  }

  Widget _buildTitle() {
    return Column(
      children: [
        Text(
          "SixEyesX",
          style: TextStyle(
            fontSize: 22,
            fontWeight: FontWeight.bold,
            color: Colors.white,
            fontFamily: 'Orbitron',
            letterSpacing: 2,
            shadows: [
              Shadow(color: neonCyan.withOpacity(0.6), blurRadius: 12),
            ],
          ),
        ),
        const SizedBox(height: 8),
        Text(
          "AUTHENTICATION GATEWAY",
          style: TextStyle(
            fontSize: 10,
            color: neonCyan.withOpacity(0.7),
            fontFamily: 'ShareTechMono',
            letterSpacing: 2,
          ),
        ),
      ],
    );
  }

  Widget _buildInput(TextEditingController controller, String label, IconData icon, [bool isPassword = false]) {
    return Container(
      height: 58,
      padding: const EdgeInsets.symmetric(horizontal: 20),
      decoration: BoxDecoration(
        color: bgCard,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: neonCyan.withOpacity(0.3), width: 1),
        boxShadow: [
          BoxShadow(color: neonCyan.withOpacity(0.05), blurRadius: 8),
        ],
      ),
      child: TextFormField(
        controller: controller,
        obscureText: isPassword ? _obscurePassword : false,
        style: const TextStyle(color: Colors.white, fontSize: 15, fontFamily: 'ShareTechMono'),
        decoration: InputDecoration(
          labelText: label,
          labelStyle: TextStyle(color: neonCyan.withOpacity(0.6), fontSize: 12),
          prefixIcon: Icon(icon, color: neonCyan, size: 22),
          suffixIcon: isPassword
              ? IconButton(
                  icon: Icon(_obscurePassword ? Icons.visibility_off_rounded : Icons.visibility_rounded, color: Colors.white54, size: 20),
                  onPressed: () => setState(() => _obscurePassword = !_obscurePassword),
                )
              : null,
          border: InputBorder.none,
          contentPadding: EdgeInsets.zero,
        ),
        validator: (value) => value == null || value.isEmpty ? 'Required' : null,
      ),
    );
  }

  Widget _buildButton() {
    final double fullWidth = MediaQuery.of(context).size.width - 48;
    return AnimatedContainer(
      duration: const Duration(milliseconds: 300),
      width: isLoading ? 60 : fullWidth,
      height: 58,
      decoration: BoxDecoration(
        gradient: LinearGradient(colors: [neonPink, neonPurple]),
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(color: neonPink.withOpacity(0.5), blurRadius: 20, offset: const Offset(0, 8)),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: isLoading ? null : login,
          borderRadius: BorderRadius.circular(16),
          child: Center(
            child: isLoading
                ? const SizedBox(width: 24, height: 24, child: CircularProgressIndicator(strokeWidth: 3, color: Colors.white))
                : Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Icon(Icons.login_rounded, color: Colors.white, size: 22),
                      const SizedBox(width: 12),
                      const Text("ACCESS SYSTEM", style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold, letterSpacing: 2)),
                    ],
                  ),
          ),
        ),
      ),
    );
  }

  Widget _buildPriceList() {
    final packages = [
      {"name": "BASIC", "price": "50K", "duration": "30 DAYS", "color": neonGreen, "icon": Icons.brightness_1_rounded},
      {"name": "PRO", "price": "120K", "duration": "90 DAYS", "color": neonCyan, "icon": Icons.flash_on_rounded},
      {"name": "ULTRA", "price": "250K", "duration": "LIFETIME", "color": neonPink, "icon": Icons.stars_rounded},
    ];

    return Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(width: 30, height: 2, color: neonCyan.withOpacity(0.5)),
            const SizedBox(width: 12),
            Text(
              "ACCESS PLANS",
              style: TextStyle(
                fontFamily: 'Orbitron',
                fontSize: 12,
                color: neonCyan,
                letterSpacing: 3,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(width: 12),
            Container(width: 30, height: 2, color: neonCyan.withOpacity(0.5)),
          ],
        ),
        const SizedBox(height: 16),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: packages.map((pkg) {
            final Color pkgColor = pkg["color"] as Color;
            return Expanded(
              child: Container(
                margin: const EdgeInsets.symmetric(horizontal: 4),
                padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 8),
                decoration: BoxDecoration(
                  color: bgCard,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: pkgColor.withOpacity(0.5), width: 1),
                  boxShadow: [
                    BoxShadow(color: pkgColor.withOpacity(0.2), blurRadius: 10),
                  ],
                ),
                child: Column(
                  children: [
                    Icon(pkg["icon"] as IconData, color: pkgColor, size: 24),
                    const SizedBox(height: 8),
                    Text(
                      pkg["name"] as String,
                      style: TextStyle(
                        fontFamily: 'Orbitron',
                        fontSize: 10,
                        color: pkgColor,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      pkg["price"] as String,
                      style: const TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.bold),
                    ),
                    Text(
                      pkg["duration"] as String,
                      style: TextStyle(color: Colors.white54, fontSize: 8),
                    ),
                  ],
                ),
              ),
            );
          }).toList(),
        ),
      ],
    );
  }

  Widget _buildNeonFooter() {
    return Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.security_rounded, color: neonGreen, size: 12),
            const SizedBox(width: 6),
            Text("ENCRYPTED CONNECTION", style: TextStyle(color: Colors.white38, fontSize: 9, fontFamily: 'ShareTechMono', letterSpacing: 1)),
            const SizedBox(width: 12),
            Icon(Icons.flash_on_rounded, color: neonPink, size: 12),
            const SizedBox(width: 6),
            Text("24/7 SUPPORT", style: TextStyle(color: Colors.white38, fontSize: 9, fontFamily: 'ShareTechMono', letterSpacing: 1)),
          ],
        ),
        const SizedBox(height: 8),
        Text(
          "SixEyesX v8.5",
          style: TextStyle(color: Colors.white24, fontSize: 8, fontFamily: 'ShareTechMono', letterSpacing: 1),
        ),
      ],
    );
  }
}