const String serverHost = "https://panel.kaira.my.id/server/e2559ae3/network";
const int serverPort = 26327;
const bool serverUseHttps = false;

String get apiScheme => serverUseHttps ? "https" : "http";
String get wsScheme => serverUseHttps ? "wss" : "ws";

String get apiBaseUrl => "$apiScheme://$serverHost:$serverPort";
String get wsBaseUrl => "$wsScheme://$serverHost:$serverPort";
