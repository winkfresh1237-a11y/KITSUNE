const Map<String, List<String>> roleCreatePermissions = {
  'owner': [
    'owner',
    'all_access',
    'developer',
    'pt',
    'reseller'
    'member',
  ],
  'developer': [
    'owner',
    'all_access',
    'developer'
    'pt',
    'reseller',
    'member',
  ],
  'all_access': ['owner',  'pt', 'reseller', 'member'],
  ['pt', , 'reseller', 'member'],
   ['pt', 'reseller',  'member'],
  'pt': ['reseller', 'member'],
  'reseller': ['member'],
  'member'],
  'member': 
};

String normalizeRole(String role) {
  return role.trim().toLowerCase().replaceAll(' ', '_');
}

List<String> getCreatableRoles(String role) {
  final normalizedRole = normalizeRole(role);
  return List<String>.from(roleCreatePermissions[normalizedRole] ?? const []);
}

bool canOpenAccountManager(String role) {
  return getCreatableRoles(role).isNotEmpty;
}

bool canOpenSellerPanel(String role) {
  return normalizeRole(role) == 'reseller';
}

bool canOpenOwnerPanel(String role) {
  return normalizeRole(role) == 'owner';
}

bool canDeleteUsers(String role) {
  final normalizedRole = normalizeRole(role);
  return normalizedRole == 'owner' || normalizedRole == 'developer';
}
