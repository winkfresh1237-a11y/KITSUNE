package com.dark.ZSNZ;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
