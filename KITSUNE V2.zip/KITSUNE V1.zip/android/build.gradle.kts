import org.gradle.api.JavaVersion
import org.jetbrains.kotlin.gradle.dsl.JvmTarget
import org.jetbrains.kotlin.gradle.dsl.KotlinAndroidProjectExtension
import org.jetbrains.kotlin.gradle.dsl.KotlinJvmProjectExtension
import org.jetbrains.kotlin.gradle.tasks.KotlinCompile

allprojects {
    repositories {
        google()
        mavenCentral()
    }
}

val newBuildDir: Directory = rootProject.layout.buildDirectory.dir("../../build").get()
rootProject.layout.buildDirectory.value(newBuildDir)

subprojects {
    val newSubprojectBuildDir: Directory = newBuildDir.dir(project.name)
    project.layout.buildDirectory.value(newSubprojectBuildDir)
}
subprojects {
    project.evaluationDependsOn(":app")
}

subprojects {
    plugins.withId("org.jetbrains.kotlin.android") {
        extensions.findByType(KotlinAndroidProjectExtension::class.java)?.compilerOptions?.jvmTarget?.set(
            JvmTarget.fromTarget(JavaVersion.VERSION_17.toString())
        )
    }

    plugins.withId("org.jetbrains.kotlin.jvm") {
        extensions.findByType(KotlinJvmProjectExtension::class.java)?.compilerOptions?.jvmTarget?.set(
            JvmTarget.fromTarget(JavaVersion.VERSION_17.toString())
        )
    }

    tasks.withType(KotlinCompile::class.java).configureEach {
        compilerOptions.jvmTarget.set(
            JvmTarget.fromTarget(
                JavaVersion.VERSION_17.toString()
            )
        )
    }
}

tasks.register<Delete>("clean") {
    delete(rootProject.layout.buildDirectory)
}
